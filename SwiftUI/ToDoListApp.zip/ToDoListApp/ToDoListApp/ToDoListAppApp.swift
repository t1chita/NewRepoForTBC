//
//  ToDoListAppApp.swift
//  ToDoListApp
//
//  Created by Temur Chitashvili on 23.05.24.
//

import SwiftUI

@main
struct ToDoListAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
