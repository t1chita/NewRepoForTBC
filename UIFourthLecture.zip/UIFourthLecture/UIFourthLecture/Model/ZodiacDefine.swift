//
//  ZodiacDefine.swift
//  UIFourthLecture
//
//  Created by Temur Chitashvili on 10.04.24.
//

import UIKit

enum ZodiacSings {
    case aries,taurus,gemini,cancer,leo,virgo,libra,scorpio,sagittarius,capricorn,aquarius,pisces
    
}
struct Zodiac {
    let name: ZodiacSings
    let description: String
    let poralZodiacSign: ZodiacSings
    let signImage: UIImage
}
